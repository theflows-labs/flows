// Centralized navigation constants for easy maintenance
export const PUBLIC_ROUTES = {
  HOME: '/',
  HOME_HERO: '/#hero',
  FEATURES: '/#features',
  PRICING: '/',
  CONTACT: '/#contact',
} as const;

export const AUTH_ROUTES = {
  LOGIN: '/',
  REGISTER: '/',
} as const;

// Footer link structure with proper categorization
export const FOOTER_LINKS = [
  {
    title: "Product",
    links: [
      { name: "Home", href: PUBLIC_ROUTES.HOME_HERO },
      { name: "Features", href: PUBLIC_ROUTES.FEATURES },
      { name: "Pricing", href: PUBLIC_ROUTES.PRICING },
      { name: "Contact Us", href: PUBLIC_ROUTES.CONTACT },
    ],
  },
] as const;

// Helper function to check if a route exists (not a placeholder)
export const isActiveRoute = (href: string): boolean => {
  return href !== "#" && (Object.values(PUBLIC_ROUTES).includes(href as any) || href.startsWith("/#"));
}; 