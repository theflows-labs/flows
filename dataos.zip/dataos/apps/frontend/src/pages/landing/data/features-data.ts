interface FeatureDetail {
  icon: string;
  title: string;
  description: string;
}

interface FeatureData {
  icon: string;
  mainIconClass: string;
  secondaryIcon: string;
  secondaryIconClass: string;
  title: string;
  description: string;
  gradient: string;
  borderGradient: string;
  details: {
    description: string;
    benefits: string[];
    features: FeatureDetail[];
  };
}

export const features: FeatureData[] = [
    {
      icon: 'AirplayIcon',
      mainIconClass: 'text-blue-600',
      secondaryIcon: 'SparklesIcon',
      secondaryIconClass: 'text-amber-500',
      title: 'No-Code Data Orchestration',
      description: 'Supercharge your data workflows with an intuitive no-code solution for Apache Airflow.',
      gradient: 'from-blue-500/10 to-indigo-500/10',
      borderGradient: 'from-blue-500/20 to-indigo-500/20',
      details: {
        description: 'Build, schedule, and monitor complex data pipelines without writing a single line of code. Our intuitive drag-and-drop interface makes data orchestration accessible to everyone.',
        benefits: [
          'Visual pipeline builder with drag-and-drop interface',
          'Pre-built connectors for popular data sources',
          'Real-time monitoring and alerting',
          'Version control and collaboration tools',
        ],
        features: [
          { icon: 'CodeIcon', title: 'No-Code Interface', description: 'Build complex workflows without coding' },
          { icon: 'BarChart3Icon', title: 'Real-time Monitoring', description: 'Track pipeline performance live' },
          { icon: 'NetworkIcon', title: 'Smart Connectors', description: 'Pre-built integrations for quick setup' },
          { icon: 'BoxIcon', title: 'Version Control', description: 'Track changes and collaborate safely' }
        ]
      }
    },
    {
      icon: 'BrainCircuitIcon',
      mainIconClass: 'text-indigo-600',
      secondaryIcon: 'ActivityIcon',
      secondaryIconClass: 'text-purple-500',
      title: 'AI-Powered Lakehouse Management',
      description: 'Leverage cutting-edge AI tools to build and optimize data lakehouses.',
      gradient: 'from-indigo-500/10 to-purple-500/10',
      borderGradient: 'from-indigo-500/20 to-purple-500/20',
      details: {
        description: 'Harness the power of AI to automatically optimize your data lakehouse operations. From schema detection to performance tuning, our AI handles the complexity.',
        benefits: [
          'Automated schema detection and evolution',
          'AI-driven query optimization',
          'Intelligent data quality monitoring',
          'Predictive scaling and resource allocation',
        ],
        features: [
          { icon: 'CloudIcon', title: 'Smart Schema', description: 'Automatic schema detection & updates' },
          { icon: 'DatabaseIcon', title: 'Query Optimization', description: 'AI-powered query performance' },
          { icon: 'ShieldIcon', title: 'Quality Control', description: 'Automated data quality checks' },
          { icon: 'ActivityIcon', title: 'Smart Scaling', description: 'Predictive resource management' }
        ]
      }
    },
    {
      icon: 'UsersIcon',
      mainIconClass: 'text-violet-600',
      secondaryIcon: 'LayersIcon',
      secondaryIconClass: 'text-purple-500',
      title: 'Lightweight Customer Data Platform',
      description: 'Deploy a streamlined CDP that delivers all your Customer 360 needs.',
      gradient: 'from-violet-500/10 to-purple-500/10',
      borderGradient: 'from-violet-500/20 to-purple-500/20',
      details: {
        description: 'Unify customer data across all touchpoints with our lightweight CDP solution. Create comprehensive customer profiles and activate insights across your marketing stack.',
        benefits: [
          'Unified customer profiles across channels',
          'Real-time segmentation and targeting',
          'Privacy-first data management',
          'Cross-channel journey orchestration',
        ],
        features: [
          { icon: 'UsersIcon', title: 'Unified Profiles', description: 'Complete customer view' },
          { icon: 'LayersIcon', title: 'Segmentation', description: 'Real-time audience targeting' },
          { icon: 'ShieldIcon', title: 'Privacy Control', description: 'Built-in privacy management' },
          { icon: 'ActivityIcon', title: 'Journey Mapping', description: 'Cross-channel orchestration' }
        ]
      }
    },
    {
      icon: 'FileSymlinkIcon',
      mainIconClass: 'text-blue-600',
      secondaryIcon: 'SparklesIcon',
      secondaryIconClass: 'text-amber-500',
      title: 'Integrated Data Plane',
      description: 'Simplify data transfer with our built-in data plane management.',
      gradient: 'from-blue-500/10 to-indigo-500/10',
      borderGradient: 'from-blue-500/20 to-indigo-500/20',
      details: {
        description: 'Manage all your data transfers through a unified data plane. Ensure reliable, secure, and monitored data movement across your entire infrastructure.',
        benefits: [
          'Centralized data transfer management',
          'End-to-end encryption and security',
          'Automated retry and error handling',
          'Comprehensive transfer monitoring',
        ],
        features: [
          { icon: 'NetworkIcon', title: 'Unified Transfer', description: 'Centralized data movement' },
          { icon: 'ShieldIcon', title: 'Security', description: 'End-to-end encryption' },
          { icon: 'ActivityIcon', title: 'Monitoring', description: 'Real-time transfer tracking' },
          { icon: 'BoxIcon', title: 'Error Handling', description: 'Automated retry mechanism' }
        ]
      }
    },
    {
      icon: 'DatabaseIcon',
      mainIconClass: 'text-emerald-600',
      secondaryIcon: 'ShieldIcon',
      secondaryIconClass: 'text-green-500',
      title: 'Intelligent Metadata Manager',
      description: 'Discover, catalog, and govern your data assets with AI-powered metadata management.',
      gradient: 'from-emerald-500/10 to-green-500/10',
      borderGradient: 'from-emerald-500/20 to-green-500/20',
      details: {
        description: 'Automatically discover and catalog your data assets across all systems. Track data lineage, manage schemas, and ensure data quality with intelligent governance policies.',
        benefits: [
          'Automated data discovery and cataloging',
          'Visual data lineage tracking and impact analysis',
          'Schema versioning and evolution management',
          'AI-powered data quality monitoring',
        ],
        features: [
          { icon: 'DatabaseIcon', title: 'Data Catalog', description: 'Comprehensive asset discovery' },
          { icon: 'NetworkIcon', title: 'Lineage Tracking', description: 'Visual data flow mapping' },
          { icon: 'LayersIcon', title: 'Schema Management', description: 'Version-controlled schemas' },
          { icon: 'ShieldIcon', title: 'Quality Control', description: 'Automated quality checks' }
        ]
      }
    },
    {
      icon: 'BotIcon',
      mainIconClass: 'text-orange-600',
      secondaryIcon: 'ActivityIcon',
      secondaryIconClass: 'text-red-500',
      title: 'AI-Powered Agent Platform',
      description: 'Deploy and orchestrate intelligent AI agents for automated data operations.',
      gradient: 'from-orange-500/10 to-red-500/10',
      borderGradient: 'from-orange-500/20 to-red-500/20',
      details: {
        description: 'Create, deploy, and manage sophisticated AI agents that can automate complex data workflows, monitor systems, and respond to events in real-time.',
        benefits: [
          'Intelligent task automation and workflow execution',
          'Real-time agent monitoring and health tracking',
          'Multi-agent orchestration and coordination',
          'Custom agent capabilities and extensibility',
        ],
        features: [
          { icon: 'BotIcon', title: 'Smart Automation', description: 'AI-powered task execution' },
          { icon: 'ActivityIcon', title: 'Live Monitoring', description: 'Real-time agent status' },
          { icon: 'UsersIcon', title: 'Multi-agent Ops', description: 'Coordinated agent teams' },
          { icon: 'CodeIcon', title: 'Custom Agents', description: 'Build specialized capabilities' }
        ]
      }
    }
  ]; 