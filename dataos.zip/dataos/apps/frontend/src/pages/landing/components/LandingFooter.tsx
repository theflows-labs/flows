import { useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import { FOOTER_LINKS } from "@/config/navigation";

const socialIcons = [
  {
    href: "#",
    label: "Twitter",
    svg: (
      <svg fill="currentColor" viewBox="0 0 24 24" className="w-5 h-5">
        <path d="M22.46 6c-.77.35-1.6.58-2.47.69a4.3 4.3 0 0 0 1.88-2.37 8.59 8.59 0 0 1-2.72 1.04A4.28 4.28 0 0 0 16.11 4c-2.37 0-4.29 1.92-4.29 4.29 0 .34.04.67.11.99C7.69 9.13 4.07 7.38 1.64 4.7c-.37.64-.58 1.39-.58 2.19 0 1.51.77 2.84 1.95 3.62-.72-.02-1.39-.22-1.98-.55v.06c0 2.11 1.5 3.87 3.5 4.27-.36.1-.74.16-1.13.16-.28 0-.54-.03-.8-.08.54 1.68 2.11 2.9 3.97 2.93A8.6 8.6 0 0 1 2 19.54c-.32 0-.63-.02-.94-.06A12.13 12.13 0 0 0 8.29 21.5c7.55 0 11.68-6.26 11.68-11.68 0-.18-.01-.36-.02-.54A8.18 8.18 0 0 0 24 4.59a8.36 8.36 0 0 1-2.54.7z" />
      </svg>
    ),
  },
  {
    href: "#",
    label: "GitHub",
    svg: (
      <svg fill="currentColor" viewBox="0 0 24 24" className="w-5 h-5">
        <path d="M12 2C6.48 2 2 6.58 2 12.26c0 4.5 2.87 8.32 6.84 9.67.5.09.68-.22.68-.48 0-.24-.01-.87-.01-1.7-2.78.61-3.37-1.36-3.37-1.36-.45-1.18-1.1-1.5-1.1-1.5-.9-.63.07-.62.07-.62 1 .07 1.53 1.05 1.53 1.05.89 1.56 2.34 1.11 2.91.85.09-.66.35-1.11.63-1.37-2.22-.26-4.56-1.14-4.56-5.07 0-1.12.39-2.03 1.03-2.75-.1-.26-.45-1.3.1-2.7 0 0 .84-.28 2.75 1.05A9.38 9.38 0 0 1 12 7.43c.85.004 1.71.12 2.51.35 1.91-1.33 2.75-1.05 2.75-1.05.55 1.4.2 2.44.1 2.7.64.72 1.03 1.63 1.03 2.75 0 3.94-2.34 4.81-4.57 5.07.36.32.68.94.68 1.9 0 1.37-.01 2.47-.01 2.81 0 .27.18.58.69.48A10.01 10.01 0 0 0 22 12.26C22 6.58 17.52 2 12 2z" />
      </svg>
    ),
  },
  {
    href: "#",
    label: "LinkedIn",
    svg: (
      <svg fill="currentColor" viewBox="0 0 24 24" className="w-5 h-5">
        <path d="M19 0h-14c-2.76 0-5 2.24-5 5v14c0 2.76 2.24 5 5 5h14c2.76 0 5-2.24 5-5v-14c0-2.76-2.24-5-5-5zm-11 19h-3v-10h3v10zm-1.5-11.28c-.97 0-1.75-.79-1.75-1.75s.78-1.75 1.75-1.75 1.75.79 1.75 1.75-.78 1.75-1.75 1.75zm15.5 11.28h-3v-5.6c0-1.34-.03-3.07-1.87-3.07-1.87 0-2.16 1.46-2.16 2.97v5.7h-3v-10h2.88v1.36h.04c.4-.75 1.38-1.54 2.84-1.54 3.04 0 3.6 2 3.6 4.59v5.59z" />
      </svg>
    ),
  },
];

export default function Footer() {
  const location = useLocation();
  const [activeSection, setActiveSection] = useState("hero");

  useEffect(() => {
    const handleScroll = () => {
      // Only detect sections on the landing page
      if (location.pathname === '/') {
        const sections = ['hero', 'features', 'contact'];
        const scrollPosition = window.scrollY + 100; // Offset for better UX
        
        for (const section of sections) {
          const element = document.getElementById(section);
          if (element) {
            const { offsetTop, offsetHeight } = element;
            if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
              setActiveSection(section);
              break;
            }
          }
        }
      }
    };
    
    window.addEventListener("scroll", handleScroll);
    // Call once on mount
    handleScroll();
    
    return () => window.removeEventListener("scroll", handleScroll);
  }, [location.pathname]);

  // Set active section based on current route
  useEffect(() => {
    if (location.pathname === '/') {
      setActiveSection("hero"); // Default to hero on landing page
    } else {
      // For other pages, don't highlight any navigation item
      setActiveSection('');
    }
  }, [location.pathname]);
  
  const isActiveLink = (href: string) => {
    if (href === "#") return false;
    
    // For anchor links (like /#hero, /#features, /#contact), check specific section
    if (href.startsWith("/#")) {
      if (location.pathname !== "/") return false;
      
      const section = href.substring(2); // Remove '/#' to get section name
      return activeSection === section;
    }
    
    // For regular routes, check exact match
    return location.pathname === href;
  };

  return (
    <footer className="w-full bg-[#1A1A2E] py-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* White rounded card */}
        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
          <div className="p-8 md:p-12">
            {/* Top section with columns */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 lg:gap-12 mb-8">
              {FOOTER_LINKS.map((col, idx) => (
                <div key={idx} className="space-y-4">
                  <h4 className="font-bold text-lg text-blue-900">{col.title}</h4>
                  <ul className="space-y-3">
                    {col.links.map((link, i) => (
                      <li key={i}>
                        <a 
                          href={link.href} 
                          className={`text-sm transition-colors ${
                            isActiveLink(link.href)
                              ? "text-blue-600 font-medium"
                              : "text-black font-bold hover:text-gray-700"
                          }`}
                        >
                          {link.name}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
            
            {/* Bottom section with buttons and copyright */}
            <div className="flex flex-col md:flex-row items-center justify-end gap-6 pt-6 border-t border-gray-200">
              
               
              {/* Right side - Copyright and social icons */}
              <div className="flex flex-col sm:flex-row items-center gap-4">
                <div className="text-sm text-blue-900">
                  © 2025 DataOS. All rights reserved.
                </div>
                <div className="flex items-center gap-4">
                  {socialIcons.map((icon, idx) => (
                    <a key={idx} href={icon.href} aria-label={icon.label} className="text-blue-900 hover:text-blue-700 transition-colors">
                      {icon.svg}
                    </a>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
} 