import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { cn } from "../../../lib/utils";
import { MenuIcon } from "lucide-react";
import { Sheet, SheetTrigger, SheetContent, SheetClose } from "@/components/ui/sheet";
import { AUTH_ROUTES } from "@/config/navigation";

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState("hero");
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
      
      // Only detect sections on the landing page
      if (location.pathname === '/') {
        const sections = ['hero', 'features', 'contact'];
        const scrollPosition = window.scrollY + 100; // Offset for better UX
        
        for (const section of sections) {
          const element = document.getElementById(section);
          if (element) {
            const { offsetTop, offsetHeight } = element;
            if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
              setActiveSection(section);
              break;
            }
          }
        }
      }
    };
    
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [location.pathname]);

  // Set active section based on current route
  useEffect(() => {
    if (location.pathname === '/') {
      setActiveSection("hero"); // Default to hero on landing page
    } else {
      // For other pages (About, Careers, Partners, etc.), don't highlight any navigation item
      setActiveSection('');
    }
  }, [location.pathname]);

  const handleSignIn = () => {
    window.location.href = AUTH_ROUTES.LOGIN;
  };

  const handleTryForFree = () => {
    window.location.href = AUTH_ROUTES.REGISTER;
  };

  const isActive = (section: string) => {
    // Only show active states on the landing page
    return location.pathname === '/' && activeSection === section;
  };

  const getLinkClasses = (section: string) => {
    return cn(
      "text-sm font-medium transition-colors relative",
      isActive(section) 
        ? "text-blue-600 font-semibold after:absolute after:bottom-[-4px] after:left-0 after:w-full after:h-0.5 after:bg-blue-600 after:rounded-full" 
        : "text-gray-700 hover:text-blue-600"
    );
  };

  const getMobileLinkClasses = (section: string) => {
    return cn(
      "text-lg font-medium transition-colors relative",
      isActive(section) 
        ? "text-blue-600 font-semibold after:absolute after:bottom-[-2px] after:left-0 after:w-full after:h-0.5 after:bg-blue-600 after:rounded-full" 
        : "text-black hover:text-blue-600"
    );
  };

  return (
    <nav
      className={cn(
        "fixed left-1/2 z-50 -translate-x-1/2 transition-all duration-300",
        scrolled
          ? "w-[calc(100vw-2rem)] max-w-6xl rounded-xl top-2 bg-background/95 shadow-lg border"
          : "w-[calc(100vw-4rem)] max-w-5xl rounded-full top-4 bg-background/80 shadow-lg border"
      )}
    >
      <div className="container flex items-center justify-between transition-all duration-300 px-4 py-3 md:py-4">
        {/* Logo */}
        <div className="flex items-center">
          <a href="/" className="font-bold text-xl">DataOS</a>
        </div>
        {/* Desktop nav */}
        <div className="hidden md:flex gap-6">
          <a href="/#hero" className={getLinkClasses("hero")}>Home</a>
          <a href="/#features" className={getLinkClasses("features")}>Features</a>
          <a href="/" className="text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors">Pricing</a>
          <a href="/#contact" className={getLinkClasses("contact")}>Contact Us</a>
        </div>
        <div className="hidden md:flex items-center gap-4">
          <button onClick={handleSignIn} className="text-sm font-medium hover:text-primary transition-colors">
            Sign in
          </button>
          <button onClick={handleTryForFree} className="bg-primary text-primary-foreground hover:bg-primary/90 px-4 py-2 rounded-md text-sm font-medium transition-colors">
            Try for free
          </button>
        </div>
        {/* Mobile Drawer */}
        <div className="md:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <button aria-label="Open menu">
                <MenuIcon size={28} />
              </button>
            </SheetTrigger>
            <SheetContent className="p-6">
              <ul className="space-y-6 mb-8">
                <li><a href="/#hero" className={getMobileLinkClasses("hero")}>Home</a></li>
                <li><a href="/#features" className={getMobileLinkClasses("features")}>Features</a></li>
                <li><a href="/" className="text-lg font-medium text-black hover:text-blue-600 transition-colors">Pricing</a></li>
                <li><a href="/#contact" className={getMobileLinkClasses("contact")}>Contact Us</a></li>
              </ul>
              <div className="space-y-3">
                <button onClick={handleTryForFree} className="w-full py-3 rounded-md bg-primary text-white font-semibold text-base hover:bg-primary/90 transition">
                  Try for free
                </button>
                <button onClick={handleSignIn} className="w-full py-3 rounded-md border border-black text-black font-semibold text-base hover:bg-gray-100 transition">
                  Sign in
                </button>
              </div>
              <SheetClose asChild>
                <button className="block w-full mt-6 text-center text-base text-black font-medium">Close</button>
              </SheetClose>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
} 