// Export all landing page components from a single entry point
export { Navbar as LandingHeader } from './LandingHeader';
export { default as LandingFooter } from './LandingFooter'; 