"use client";

import { useRef } from "react";
import { AnimatedBeam } from "@/components/magicui/animated-beam";

export default function Features() {
  const containerRef = useRef<HTMLDivElement>(null);
  const div1Ref = useRef<HTMLDivElement>(null);
  const div2Ref = useRef<HTMLDivElement>(null);
  const div3Ref = useRef<HTMLDivElement>(null);
  const div4Ref = useRef<HTMLDivElement>(null);
  const div5Ref = useRef<HTMLDivElement>(null);
  const div6Ref = useRef<HTMLDivElement>(null);
  const div7Ref = useRef<HTMLDivElement>(null);

  return (
    <section id="features" className="py-20 pb-0 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-2">
            One platform, endless data possibilities
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Launch hundreds of features first with a unified development approach that brings 30%
            accountability to your data solutions.
          </p>
        </div>
        <div
          ref={containerRef}
          className="relative w-full h-[600px] bg-gradient-to-br from-gray-50 to-gray-100 rounded-2xl p-8"
        >
        {/* Center - DataOS */}
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
          <div
            ref={div4Ref}
            className="w-40 h-32 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl shadow-xl border border-gray-200 flex items-center justify-center hover:shadow-2xl transition-all duration-300 hover:scale-105"
          >
            <div className="text-center">
              <div className="w-16 h-16 bg-white/20 rounded-lg flex items-center justify-center mx-auto mb-2">
                <span className="text-3xl text-white font-bold">D</span>
              </div>
              <h4 className="text-sm font-bold text-white">DataOS</h4>
            </div>
          </div>
        </div>

        {/* Left Column - Input Components */}
        <div className="absolute left-8 top-1/2 transform -translate-y-1/2 space-y-16">
          <div
            ref={div1Ref}
            className="w-36 h-24 bg-gradient-to-r from-blue-500/10 to-indigo-500/10 rounded-xl shadow-lg border border-blue-500/20 flex items-center justify-center hover:shadow-xl transition-all duration-300 hover:scale-105"
          >
            <div className="text-center">
              <div className="w-10 h-10 bg-white/80 rounded-lg flex items-center justify-center mx-auto mb-1">
                <span className="text-lg text-white">📺</span>
              </div>
              <h4 className="text-xs font-semibold text-gray-900 leading-tight px-2">No-Code Data Orchestration</h4>
            </div>
          </div>

          <div
            ref={div2Ref}
            className="w-36 h-24 bg-gradient-to-r from-indigo-500/10 to-purple-500/10 rounded-xl shadow-lg border border-indigo-500/20 flex items-center justify-center hover:shadow-xl transition-all duration-300 hover:scale-105"
          >
            <div className="text-center">
              <div className="w-10 h-10 bg-white/80 rounded-lg flex items-center justify-center mx-auto mb-1">
                <span className="text-lg text-white">🧠</span>
              </div>
              <h4 className="text-xs font-semibold text-gray-900 leading-tight px-2">AI-Powered Lakehouse Management</h4>
            </div>
          </div>

          <div
            ref={div3Ref}
            className="w-36 h-24 bg-gradient-to-r from-violet-500/10 to-purple-500/10 rounded-xl shadow-lg border border-violet-500/20 flex items-center justify-center hover:shadow-xl transition-all duration-300 hover:scale-105"
          >
            <div className="text-center">
              <div className="w-10 h-10 bg-white/80 rounded-lg flex items-center justify-center mx-auto mb-1">
                <span className="text-lg text-white">👥</span>
              </div>
              <h4 className="text-xs font-semibold text-gray-900 leading-tight px-2">Lightweight Customer Data Platform</h4>
            </div>
          </div>
        </div>

        {/* Right Column - Output Components */}
        <div className="absolute right-8 top-1/2 transform -translate-y-1/2 space-y-16">
          <div
            ref={div5Ref}
            className="w-36 h-24 bg-gradient-to-r from-blue-500/10 to-indigo-500/10 rounded-xl shadow-lg border border-blue-500/20 flex items-center justify-center hover:shadow-xl transition-all duration-300 hover:scale-105"
          >
            <div className="text-center">
              <div className="w-10 h-10 bg-white/80 rounded-lg flex items-center justify-center mx-auto mb-1">
                <span className="text-lg text-white">📄</span>
              </div>
              <h4 className="text-xs font-semibold text-gray-900 leading-tight px-2">Integrated Data Plane</h4>
            </div>
          </div>

          <div
            ref={div6Ref}
            className="w-36 h-24 bg-gradient-to-r from-emerald-500/10 to-green-500/10 rounded-xl shadow-lg border border-emerald-500/20 flex items-center justify-center hover:shadow-xl transition-all duration-300 hover:scale-105"
          >
            <div className="text-center">
              <div className="w-10 h-10 bg-white/80 rounded-lg flex items-center justify-center mx-auto mb-1">
                <span className="text-lg text-white">🗄️</span>
              </div>
              <h4 className="text-xs font-semibold text-gray-900 leading-tight px-2">Intelligent Metadata Manager</h4>
            </div>
          </div>

          <div
            ref={div7Ref}
            className="w-36 h-24 bg-gradient-to-r from-orange-500/10 to-red-500/10 rounded-xl shadow-lg border border-orange-500/20 flex items-center justify-center hover:shadow-xl transition-all duration-300 hover:scale-105"
          >
            <div className="text-center">
              <div className="w-10 h-10 bg-white/80 rounded-lg flex items-center justify-center mx-auto mb-1">
                <span className="text-lg text-white">🤖</span>
              </div>
              <h4 className="text-xs font-semibold text-gray-900 leading-tight px-2">AI-Powered Agent Platform</h4>
            </div>
          </div>
        </div>

        {/* Animated Beams - Left side to center */}
        <AnimatedBeam
          containerRef={containerRef}
          fromRef={div1Ref}
          toRef={div4Ref}
          curvature={-100}
          endYOffset={-15}
          startXOffset={20}
          endXOffset={-20}
        />
        <AnimatedBeam
          containerRef={containerRef}
          fromRef={div2Ref}
          toRef={div4Ref}
          startXOffset={20}
          endXOffset={-20}
        />
        <AnimatedBeam
          containerRef={containerRef}
          fromRef={div3Ref}
          toRef={div4Ref}
          curvature={100}
          endYOffset={15}
          startXOffset={20}
          endXOffset={-20}
        />

        {/* Animated Beams - Right side to center with reverse */}
        <AnimatedBeam
          containerRef={containerRef}
          fromRef={div5Ref}
          toRef={div4Ref}
          curvature={-100}
          endYOffset={-15}
          startXOffset={-20}
          endXOffset={20}
          reverse
        />
        <AnimatedBeam
          containerRef={containerRef}
          fromRef={div6Ref}
          toRef={div4Ref}
          startXOffset={-20}
          endXOffset={20}
          reverse
        />
        <AnimatedBeam
          containerRef={containerRef}
          fromRef={div7Ref}
          toRef={div4Ref}
          curvature={100}
          endYOffset={15}
          startXOffset={-20}
          endXOffset={20}
          reverse
        />
        </div>
      </div>
    </section>
  );
}


