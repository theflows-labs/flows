export default function ContactUs() {
  const benefits = [
    "Reduce data pipeline development time by 70%",
    "Centralize data governance and security", 
    "Eliminate data silos across your organization",
    "Scale seamlessly as your data needs grow"
  ];

  return (
    <section id="contact" className="py-0 bg-white mb-16">
      <div className="w-full py-8 mb-0">
        <h1 className="text-4xl md:text-5xl font-extrabold text-center text-black mb-0">Contact Us</h1>
      </div>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        <div className="max-w-4xl mx-auto text-center mb-12 mt-8">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
            Ready to transform your data operations?
          </h2>
          <p className="text-lg text-gray-600">
            Join hundreds of data-driven organizations that trust DataOS to power their analytics infrastructure.
          </p>
        </div>
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden max-w-5xl mx-auto">
          <div className="md:flex">
            {/* Left: Benefits */}
            <div className="md:w-1/2 p-8 md:p-12 bg-gradient-to-b from-blue-50 via-indigo-50 to-indigo-100 text-gray-900 flex flex-col justify-between">
              <div>
                <h3 className="text-2xl font-bold mb-6 text-gray-900">Why choose DataOS</h3>
                <ul className="space-y-4">
                  {benefits.map((benefit, index) => (
                    <li key={index} className="flex items-start">
                      <svg className="w-5 h-5 mr-3 mt-1 flex-shrink-0 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      <span className="text-gray-800">{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="mt-8 p-4 bg-white/80 backdrop-blur-sm rounded-lg border border-gray-200 shadow-sm">
                <p className="italic text-gray-700">
                  "DataOS has completely transformed how we manage our data pipelines. What used to take weeks now happens in hours."
                </p>
                <div className="mt-3 font-medium text-gray-800">
                  — Data Engineering Lead, Fortune 500 Company
                </div>
              </div>
            </div>
            {/* Right: Form */}
            <div className="md:w-1/2 p-8 md:p-12 bg-white">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">
                Start your free trial
              </h3>
              <form className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                    Full Name
                  </label>
                  <input type="text" id="name" className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-600 focus:border-blue-600" placeholder="Enter your name" />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                    Work Email
                  </label>
                  <input type="email" id="email" className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-600 focus:border-blue-600" placeholder="you@company.com" />
                </div>
                <div>
                  <label htmlFor="company" className="block text-sm font-medium text-gray-700 mb-1">
                    Company
                  </label>
                  <input type="text" id="company" className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-600 focus:border-blue-600" placeholder="Your company name" />
                </div>
                <button type="submit" className="w-full px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-700 text-white rounded-md hover:from-blue-700 hover:to-indigo-800 transition-all duration-300 mt-2 shadow-lg">
                  Get Started Free
                </button>
              </form>
              <p className="text-sm text-gray-500 mt-4 text-center">
                No credit card required. Free 14-day trial.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
} 