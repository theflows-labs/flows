// Export all landing page sections from a single entry point
export { default as Hero } from './Hero';
export { default as FeatureDetails } from './FeatureDetails';
export { default as ContactUs } from './ContactUs'; 
export { default as AiagentSection } from './AiagentSection';
export { default as Features } from './Features';