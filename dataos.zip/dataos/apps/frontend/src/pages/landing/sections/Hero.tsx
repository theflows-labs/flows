
import { AnimatedGradientText } from "@/components/magicui/animated-gradient-text";
import { TypingAnimation } from "@/components/magicui/typing-animation";
import { DotPattern } from "@/components/magicui/dot-pattern";

export default function Hero() {
    return (
      <section id="hero" className="relative pt-32 pb-32 md:pt-40 md:pb-40 bg-gradient-to-b from-[#f5f3ff] to-[#f8f7fc] overflow-hidden">
        {/* Dot Pattern Background */}
        <div className="absolute inset-0 w-full h-full">
          <DotPattern
            width={16}
            height={16}
            cr={2}
            glow={true}
            className="opacity-50 text-purple-500"
          />
        </div>      

        {/* Hero Content on Top */}
        <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            {/* Announcement Badge */}
            <div className="flex justify-center mb-8">
              <a
                href="#"
                className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-orange-200 bg-white/80 text-orange-600 text-sm font-medium shadow-sm hover:bg-orange-50 transition"
              >
                Super charge your data teams with dataOS 🚀
                <span className="ml-1 text-orange-400">→</span>
              </a>
            </div>
            {/* Main Title with Animated Gradient */}
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-extrabold tracking-tight mb-6 leading-tight">
              <AnimatedGradientText className="text-4xl md:text-6xl lg:text-7xl font-extrabold tracking-tight leading-tight">
                The Operating System for Data Teams
              </AnimatedGradientText>
            </h1>
            {/* Subtitle with Typing Animation */}
            <TypingAnimation
              className="text-xl md:text-2xl text-slate-600 mb-10 leading-relaxed font-medium"
              duration={50}
              delay={1000}
            >
              Unify your data infrastructure with a comprehensive platform that empowers teams to orchestrate, analyze, and deliver insights at scale.
            </TypingAnimation>
            {/* Enhanced Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="border-2 border-slate-800 text-slate-800 bg-white/90 backdrop-blur-sm px-8 py-3 rounded-lg text-lg font-semibold hover:bg-white hover:shadow-lg transition-all duration-300">
                Get a Demo
              </button>
              <button className="bg-gradient-to-r from-blue-600 to-blue-500 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:from-blue-700 hover:to-blue-600 hover:shadow-lg transition-all duration-300">
                Try DataOS for Free
              </button>
            </div>
          </div>
        </div>
      </section>
    )
  } 