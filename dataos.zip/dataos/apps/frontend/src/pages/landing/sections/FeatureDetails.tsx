"use client";

import { features } from '../data/features-data';
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { AnimatedList } from "@/components/magicui/animated-list";

// Icon mapping for main features
const mainIconMap: { [key: string]: string } = {
  'AirplayIcon': '📺',
  'BrainCircuitIcon': '🧠',
  'UsersIcon': '👥',
  'FileSymlinkIcon': '📄',
  'DatabaseIcon': '🗄️',
  'BotIcon': '🤖'
};

// Icon mapping for sub-features
const subIconMap: { [key: string]: string } = {
  'CodeIcon': '💻',
  'BarChart3Icon': '📊',
  'NetworkIcon': '🔗',
  'BoxIcon': '📦',
  'CloudIcon': '☁️',
  'DatabaseIcon': '🗄️',
  'ShieldIcon': '🛡️',
  'ActivityIcon': '⚡',
  'UsersIcon': '👥',
  'LayersIcon': '📚',
  'BotIcon': '🤖'
};

// Color themes for each feature - Text colors set to black to match the image
const featureThemes = [
  { // No-Code Data Orchestration
    light: { bg: 'from-purple-50 via-purple-50 to-purple-100', text: 'gray', icon: 'from-purple-600 to-purple-700' },
    dark: { bg: 'from-purple-900 via-purple-800 to-purple-900', text: 'gray', icon: 'from-purple-600 to-purple-700' }
  },
  { // AI-Powered Lakehouse
    light: { bg: 'from-indigo-50 via-indigo-50 to-purple-100', text: 'gray', icon: 'from-indigo-600 to-purple-700' },
    dark: { bg: 'from-indigo-900 via-purple-800 to-purple-900', text: 'gray', icon: 'from-indigo-600 to-purple-700' }
  },
  { // Customer Data Platform
    light: { bg: 'from-violet-50 via-violet-50 to-purple-100', text: 'gray', icon: 'from-violet-600 to-purple-700' },
    dark: { bg: 'from-violet-900 via-purple-800 to-purple-900', text: 'gray', icon: 'from-violet-600 to-purple-700' }
  },
  { // Data Plane
    light: { bg: 'from-blue-50 via-indigo-50 to-indigo-100', text: 'gray', icon: 'from-blue-600 to-indigo-700' },
    dark: { bg: 'from-blue-900 via-indigo-800 to-indigo-900', text: 'gray', icon: 'from-blue-600 to-indigo-700' }
  },
  { // Metadata Manager
    light: { bg: 'from-emerald-50 via-green-50 to-green-100', text: 'gray', icon: 'from-emerald-600 to-green-700' },
    dark: { bg: 'from-emerald-900 via-green-800 to-green-900', text: 'gray', icon: 'from-emerald-600 to-green-700' }
  },
  { // AI Agent Platform
    light: { bg: 'from-orange-50 via-red-50 to-red-100', text: 'gray', icon: 'from-orange-600 to-red-700' },
    dark: { bg: 'from-orange-900 via-red-800 to-red-900', text: 'gray', icon: 'from-orange-600 to-red-700' }
  }
];

interface Item {
  name: string;
  description: string;
  icon: string;
  color: string;
  time?: string;
}

const Notification = ({ name, description, icon, color, time }: Item) => {
  return (
    <figure
      className={cn(
        "relative mx-auto min-h-fit w-full max-w-[400px] cursor-pointer overflow-hidden rounded-2xl p-4",
        "transition-all duration-200 ease-in-out hover:scale-[103%]",
        "bg-white [box-shadow:0_0_0_1px_rgba(0,0,0,.03),0_2px_4px_rgba(0,0,0,.05),0_12px_24px_rgba(0,0,0,.05)]",
        "transform-gpu dark:bg-transparent dark:backdrop-blur-md dark:[border:1px_solid_rgba(255,255,255,.1)] dark:[box-shadow:0_-20px_80px_-20px_#ffffff1f_inset]",
      )}
    >
      <div className="flex flex-row items-center gap-3">
        <div
          className="flex size-10 items-center justify-center rounded-2xl"
          style={{
            backgroundColor: color,
          }}
        >
          <span className="text-lg">{icon}</span>
        </div>
        <div className="flex flex-col overflow-hidden">
          <figcaption className="flex flex-row items-center whitespace-pre text-lg font-medium dark:text-white ">
            <span className="text-sm sm:text-lg">{name}</span>
            {time && (
              <>
                <span className="mx-1">·</span>
                <span className="text-xs text-gray-500">{time}</span>
              </>
            )}
          </figcaption>
          <p className="text-sm font-normal dark:text-white/60">
            {description}
          </p>
        </div>
      </div>
    </figure>
  );
};

export function AnimatedListDemo({
  className,
  items,
}: {
  className?: string;
  items: Item[];
}) {
  return (
    <div
      className={cn(
        "relative flex w-full flex-col overflow-hidden p-2",
        className,
      )}
    >
      <AnimatedList>
        {items.map((item, idx) => (
          <Notification {...item} key={idx} />
        ))}
      </AnimatedList>

      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-1/4 bg-gradient-to-t from-background"></div>
    </div>
  );
}

// Reusable FeatureCard component
const FeatureCard = ({ feature, index }: { feature: any; index: number }) => {
  const theme = featureThemes[index];
  const isAnimationOnRight = index % 2 === 0;
  const iconColorSets: string[][] = [
    ["#00C9A7", "#FFB800", "#FF3D71", "#1E86FF"], // No-Code
    ["#6366F1", "#7C3AED", "#0EA5E9", "#10B981"], // Lakehouse
    ["#8B5CF6", "#06B6D4", "#F59E0B", "#EF4444"], // CDP
    ["#3B82F6", "#10B981", "#F59E0B", "#8B5CF6"], // Data Plane
    ["#34D399", "#06B6D4", "#3B82F6", "#10B981"], // Metadata Manager
    ["#F97316", "#EF4444", "#22C55E", "#3B82F6"], // Agent Platform
  ];
  const demoIconColors = iconColorSets[index % iconColorSets.length];

  const StaticInfoBox = () => (
    <div className="max-w-xl">
      <div className="flex flex-col items-start mb-4">
        <div className="w-14 h-14 bg-white rounded-full flex items-center justify-center shadow-md border border-gray-200 mb-3">
          <span className="text-gray-800 text-xl">{mainIconMap[feature.icon]}</span>
        </div>
        <h3 className="text-2xl md:text-3xl font-bold text-gray-900 leading-tight">
          {feature.title}
        </h3>
      </div>
      <p className="text-lg text-gray-900 mb-6 leading-relaxed">
        {feature.details.description}
      </p>
      <div className="space-y-3 mb-2">
        {feature.details.benefits.map((benefit: string, idx: number) => (
          <div key={idx} className="flex items-center">
            <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center mr-3 shadow-sm">
              <Check className="w-4 h-4 text-white" />
            </div>
            <span className="text-gray-900 font-medium">{benefit}</span>
          </div>
        ))}
      </div>
    </div>
  );

  // Legacy components replaced by StaticInfoBox + Animated list

  return (
    <div className="mb-12">
      <div className="flex flex-col md:flex-row bg-white rounded-3xl shadow-2xl overflow-hidden">
        {/* Left Side */}
        <div className={`w-full md:w-1/2 ${!isAnimationOnRight ? '' : `bg-gradient-to-b ${theme.light.bg}`} p-8 md:p-10 flex flex-col justify-start`}>
          {isAnimationOnRight ? (
            <StaticInfoBox />
          ) : (
            <AnimatedListDemo
              className="h-[420px] md:h-[480px]"
              items={feature.details.features.map((subFeature: any, idx: number) => ({
                name: subFeature.title,
                description: subFeature.description,
                icon: subIconMap[subFeature.icon],
                color: demoIconColors[idx % demoIconColors.length],
                time: '',
              }))}
            />
          )}
        </div>

        {/* Right Side */}
        <div className={`w-full md:w-1/2 ${isAnimationOnRight ? '' : `bg-gradient-to-b ${theme.light.bg}`} p-8 md:p-10 flex flex-col justify-start`}>
          {isAnimationOnRight ? (
            <AnimatedListDemo
              className="h-[420px] md:h-[480px]"
              items={feature.details.features.map((subFeature: any, idx: number) => ({
                name: subFeature.title,
                description: subFeature.description,
                icon: subIconMap[subFeature.icon],
                color: demoIconColors[idx % demoIconColors.length],
                time: '',
              }))}
            />
          ) : (
            <StaticInfoBox />
          )}
        </div>
      </div>
    </div>
  );
};

export default function FeatureDetails() {

  return (
    <section id="feature-cards" className="py-20 bg-gray-50">
      <div className="w-full">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Cards only (no animated beam here) */}
          {/* Feature Cards - Using DRY principle */}
          {features.map((feature, index) => (
            <FeatureCard key={index} feature={feature} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
} 