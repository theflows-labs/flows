import { LandingHeader, LandingFooter } from './landing/components';
import { Hero, FeatureDetails, ContactUs, AiagentSection, Features } from './landing/sections';

export function Landing() {
  return (
    <div className="min-h-screen flex flex-col">
      <LandingHeader />
      <main className="flex-1">
        <Hero />
        <Features />
        <AiagentSection />
        <FeatureDetails />
        <ContactUs />
      </main>
      <LandingFooter />
    </div>
  );
} 