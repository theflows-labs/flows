"use client";

import { cn } from "@/lib/utils";
import { useEffect, useRef, useState } from "react";

interface FeatureItem {
  icon: string;
  title: string;
  description: string;
}

interface AnimatedFeatureListProps {
  className?: string;
  features: FeatureItem[];
  delay?: number;
  continuous?: boolean;
}

const FeatureCard = ({ icon, title, description }: FeatureItem) => {
  return (
    <figure
      className={cn(
        "relative mx-auto min-h-fit w-full max-w-[400px] cursor-pointer overflow-hidden rounded-2xl p-6",
        // animation styles
        "transition-all duration-200 ease-in-out hover:scale-[103%]",
        // light styles
        "bg-white [box-shadow:0_0_0_1px_rgba(0,0,0,.03),0_2px_4px_rgba(0,0,0,.05),0_12px_24px_rgba(0,0,0,.05)]",
        // dark styles
        "transform-gpu dark:bg-transparent dark:backdrop-blur-md dark:[border:1px_solid_rgba(255,255,255,.1)] dark:[box-shadow:0_-20px_80px_-20px_#ffffff1f_inset]",
        // hover effects
        "hover:border-blue-300 hover:shadow-sm"
      )}
    >
      <div className="flex flex-row items-center gap-3">
        <div className="flex size-8 items-center justify-center rounded-lg bg-blue-50">
          <span className="text-lg">{icon}</span>
        </div>
        <div className="flex flex-col overflow-hidden">
          <figcaption className="flex flex-row items-center whitespace-pre text-lg font-semibold dark:text-white">
            <span className="text-sm sm:text-base">{title}</span>
          </figcaption>
          <p className="text-sm font-normal text-gray-600 dark:text-white/60">
            {description}
          </p>
        </div>
      </div>
    </figure>
  );
};

export function AnimatedFeatureList({
  className,
  features,
  delay = 2000,
  continuous = false,
}: AnimatedFeatureListProps) {
  const [index, setIndex] = useState(0);
  const [rotationIndex, setRotationIndex] = useState(0);
  const [isInView, setIsInView] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsInView(entry.isIntersecting);
        if (!entry.isIntersecting) {
          setIndex(0);
          setRotationIndex(0);
        }
      },
      {
        threshold: 0.1,
        rootMargin: '50px',
      }
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isInView) {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      return;
    }

    if (continuous) {
      // First show all cards progressively
      if (index < features.length - 1) {
        const timeout = setTimeout(() => {
          setIndex(prev => prev + 1);
        }, 600); // Show cards quickly first
        return () => clearTimeout(timeout);
      } else {
        // Once all cards are shown, start the cycling movement
        intervalRef.current = setInterval(() => {
          setRotationIndex((prevRotation) => (prevRotation + 1) % features.length);
        }, delay);
      }
    } else {
      // One-time progressive animation
      if (index < features.length - 1) {
        const timeout = setTimeout(() => {
          setIndex((prevIndex) => prevIndex + 1);
        }, delay);
        return () => clearTimeout(timeout);
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, [isInView, index, delay, continuous, features.length]);

  const getCardPosition = (cardIndex: number) => {
    if (!continuous || index < features.length - 1) {
      return cardIndex; // Normal position during initial show
    }
    // Calculate cyclic position based on rotation
    return (cardIndex - rotationIndex + features.length) % features.length;
  };

  return (
    <div
      ref={containerRef}
      className={cn(
        "relative overflow-hidden h-full py-6",
        className,
      )}
    >
      <div className="relative h-full">
        {features.map((feature, cardIndex) => {
          const shouldShow = cardIndex <= index;
          const position = getCardPosition(cardIndex);
          const isAnimating = continuous && index >= features.length - 1;
          
          // Calculate position in container (0 to 3 for 4 cards)
          // Position cards within the padded area (6% top/bottom for py-6)
          const containerPosition = isAnimating ? position : cardIndex;
          const paddingPercent = 6; // Approximate py-6 as percentage
          const availableSpace = 100 - (paddingPercent * 2);
          const topPercentage = paddingPercent + (containerPosition / (features.length - 1)) * availableSpace;
          
          return (
            <div
              key={feature.title}
              className={cn(
                "w-full absolute transition-all duration-700 ease-in-out",
                shouldShow ? "opacity-100" : "opacity-0",
                !isAnimating && "animate-in fade-in-0 slide-in-from-bottom-3"
              )}
              style={{
                top: `${topPercentage}%`,
                transform: 'translateY(-50%)', // Center the card at its position
                transitionDelay: shouldShow && !isAnimating ? `${cardIndex * 0.15}s` : '0s',
                zIndex: features.length - containerPosition, // Higher position = higher z-index
              }}
            >
              <FeatureCard {...feature} />
            </div>
          );
        })}
      </div>
      
      {/* Gradient fade effects */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-8 bg-gradient-to-b from-gray-50 to-transparent"></div>
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-8 bg-gradient-to-t from-gray-50 to-transparent"></div>
    </div>
  );
} 