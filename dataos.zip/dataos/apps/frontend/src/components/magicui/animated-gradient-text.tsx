import { cn } from "@/lib/utils";
import { type ComponentPropsWithoutRef } from "react";

export interface AnimatedGradientTextProps
  extends ComponentPropsWithoutRef<"span"> {
  speed?: number;
}

export function AnimatedGradientText({
  children,
  className,
  speed = 1,
  ...props
}: AnimatedGradientTextProps) {
  return (
    <span
      className={cn(
        "inline animate-gradient bg-gradient-to-r from-[#1e293b] via-[#3b82f6] to-[#1e293b] bg-[length:300%_100%] bg-clip-text text-transparent",
        className,
      )}
      style={{
        animationDuration: `${8 / speed}s`,
      }}
      {...props}
    >
      {children}
    </span>
  );
}
