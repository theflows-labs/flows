import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// API Response handling utilities
export interface ApiResponse<T> {
  success: boolean;
  data: T;
  message: string;
  errors: string[];
  total: number;
  page: number;
  size: number;
  total_pages: number;
  has_next: boolean;
  has_prev: boolean;
  metadata: Record<string, any>;
  request_id: string;
  timestamp: string;
}

export async function handleApiResponse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
  }

  const apiResponse: ApiResponse<T> = await response.json();
  
  if (!apiResponse.success) {
    throw new Error(apiResponse.message || 'API request failed');
  }
  
  return apiResponse.data;
} 